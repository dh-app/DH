// ✅ Root build.gradle.kts — Kotlin 2.0 & Compose 1.7+ compatible

plugins {
    // Define plugin versions only — modules apply them as needed
    id("com.android.application") version "8.6.0" apply false
    id("com.android.library") version "8.6.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.0" apply false
}

// 🧹 Clean task (for Build → Clean Project)
tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
