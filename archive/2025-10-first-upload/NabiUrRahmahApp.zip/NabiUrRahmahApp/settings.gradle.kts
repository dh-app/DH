// ✅ NabiUrRahmahApp — Clean Gradle Settings (Kotlin DSL)

pluginManagement {
  repositories {
    gradlePluginPortal() // For Gradle & Kotlin plugins
    google()             // For Android Gradle Plugin
    mavenCentral()       // Primary source for dependencies
  }
}

plugins {
  // ✅ Enables automatic JDK toolchain management
  id("org.gradle.toolchains.foojay-resolver-convention") version "0.8.0"
}

dependencyResolutionManagement {
  repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
  repositories {
    google()
    mavenCentral()
  }
}

rootProject.name = "NabiUrRahmahApp"

// ✅ Include app module
include(":app")
