package org.darulhuda.udupi.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun HomeScreen(nav: NavController, moreMode:Boolean=false) {
  Column(Modifier.fillMaxSize().padding(16.dp)) {
    Text(if (moreMode) "More" else "Welcome to Darul Huda Udupi", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    AssistChip(onClick = { nav.navigate("nabi") }, label = { Text("Go to Nabi ur Rahmah") })
    Spacer(Modifier.height(8.dp))
    AssistChip(onClick = { nav.navigate("library") }, label = { Text("Go to Digital Library") })
    Spacer(Modifier.height(8.dp))
    AssistChip(onClick = { nav.navigate("quran") }, label = { Text("Qur'an Printing Complex") })
  }
}
