package org.darulhuda.udupi.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.unit.dp

@Composable
fun ContactUsScreen() {
    val uri = LocalUriHandler.current
    Column(Modifier.fillMaxSize().padding(16.dp)) {

        Text("Contact Us", style = MaterialTheme.typography.headlineSmall)
        Divider(Modifier.padding(vertical = 8.dp))

        Labeled("Phone") {
            LinkLine(" +91 70224 14400", "tel:+917022414400")
            LinkLine(" +91 89718 31905", "tel:+918971831905")
            LinkLine(" +91 73378 14400", "tel:+917337814400")
        }

        Spacer(Modifier.height(8.dp))

        Labeled("Website") { LinkLine("www.darulhudaudupi.org", "https://darulhudaudupi.org") }

        Spacer(Modifier.height(8.dp))

        Labeled("Email / Social") {
            LinkLine("YouTube", "https://www.youtube.com/@DAR-UL-HUDA,UDUPI")
            LinkLine("Facebook", "https://www.facebook.com/DarulHudaUdupi/")
            LinkLine("Instagram", "https://www.instagram.com/darulhudau/")
            // add others as you like
        }

        Spacer(Modifier.height(8.dp))

        Labeled("Address") {
            Text("Dar-ul-Huda, Udupi (Karnataka), India")
        }
    }
}

@Composable
private fun Labeled(label: String, content: @Composable ColumnScope.() -> Unit) {
    Column {
        Text(label, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold))
        Spacer(Modifier.height(4.dp))
        Column(content = content)
    }
}

@Composable
private fun LinkLine(label: String, url: String) {
    val uri = LocalUriHandler.current
    val annotated = buildAnnotatedString {
        pushStringAnnotation("URL", url)
        withStyle(SpanStyle(color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)) {
            append(label)
        }
        pop()
    }
    androidx.compose.foundation.text.ClickableText(text = annotated, onClick = {
        annotated.getStringAnnotations("URL", it, it).firstOrNull()?.let { s -> uri.openUri(s.item) }
    }, style = MaterialTheme.typography.bodyLarge)
}
