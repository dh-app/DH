plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
  id("org.jetbrains.kotlin.plugin.compose")
}

android {
  namespace = "org.darulhuda.udupi"
  compileSdk = 35

  defaultConfig {
    applicationId = "org.darulhuda.udupi"
    minSdk = 23
    targetSdk = 35
    versionCode = 3
    versionName = "1.2.0"

    vectorDrawables.useSupportLibrary = true
    resourceConfigurations += listOf("en", "ar") // ✅ Multi-language support
  }

  buildTypes {
    release {
      isMinifyEnabled = true
      isShrinkResources = true
      proguardFiles(
        getDefaultProguardFile("proguard-android-optimize.txt"),
        "proguard-rules.pro"
      )
    }
    debug {
      isMinifyEnabled = false
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }

  kotlin {
    jvmToolchain(17)
  }

  buildFeatures { compose = true }

  // Keep this aligned with your Compose BOM; 1.5.15 is OK with your current BOM.
  composeOptions { kotlinCompilerExtensionVersion = "1.5.15" }

  packaging {
    resources {
      excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
  }
}

dependencies {
  // ✅ Compose BOM (keep Compose libs versionless under this)
  val composeBom = platform("androidx.compose:compose-bom:2025.01.00") // Jan 2025 BOM
  implementation(composeBom)
  androidTestImplementation(composeBom)  // for UI tests

  // ✅ Core + Lifecycle
  implementation("androidx.core:core-ktx:1.15.0")
  implementation("androidx.activity:activity-compose:1.9.3")
  implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

  // ✅ Material3 + UI (versionless → managed by BOM)
  implementation("androidx.compose.material3:material3")
  implementation("androidx.compose.ui:ui")
  implementation("androidx.compose.ui:ui-tooling-preview")
  debugImplementation("androidx.compose.ui:ui-tooling")
  implementation("androidx.compose.material:material-icons-extended")
  implementation("androidx.navigation:navigation-compose:2.8.3")
  implementation("androidx.compose.animation:animation")

  // ✅ Material (legacy XML)
  implementation("com.google.android.material:material:1.12.0")

  // ✅ Splash screen (Android 12+)
  implementation("androidx.core:core-splashscreen:1.1.0-alpha02")

  // ✅ Networking / JSON
  implementation("com.squareup.okhttp3:okhttp:4.12.0")
  implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
  implementation("com.squareup.retrofit2:retrofit:2.11.0")
  implementation("com.squareup.retrofit2:converter-moshi:2.11.0")
  implementation("com.squareup.moshi:moshi-kotlin:1.15.1")

  // ✅ Image loading
  implementation("io.coil-kt:coil-compose:2.7.0")

  // ✅ Rich Text — HTML-capable editor/renderer (Mohamed Rejeb)
  // Use this if you need to IMPORT/EXPORT/RENDER HTML or provide editing.
  implementation("com.mohamedrejeb.richeditor:richeditor-compose:1.0.0-rc13") // Maven Central
  // Ref: coordinates & version. :contentReference[oaicite:0]{index=0}

  // --- OR (optional alternative): Markdown/HTML viewer only (Halil Özercan) ---
  // implementation("com.halilibo.compose-richtext:richtext-ui-material3-android:1.0.0-alpha03")
  // (Material3 wrapper module name uses the -android variant on Maven Central.) :contentReference[oaicite:1]{index=1}

  // ✅ Coroutines
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

  // ✅ WorkManager
  implementation("androidx.work:work-runtime-ktx:2.10.0")

  // ✅ Optional: Jsoup for HTML parsing
  implementation("org.jsoup:jsoup:1.18.1")
}
